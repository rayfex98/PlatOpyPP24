function Aparicion(){
    div = document.getElementById("cuadro");
    div.style.display = "block";
}