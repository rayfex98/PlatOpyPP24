<header> 
	<ul> 
		<li><a href="index.php">Inicio</a></li>
		<li><a href="about.php">Sobre Nosotros</a></li> 
		<li><a href="contacto.php">Contacto</a></li> 
	</ul> 
</header>